# kubernetes-metrics-server
Development/Learning environment deployment of metrics-server

NOTE: DO NOT USE THIS FOR PRODUCTION USE CASES.
 This is an insecure deployment for quick deployment in a learning environment.
